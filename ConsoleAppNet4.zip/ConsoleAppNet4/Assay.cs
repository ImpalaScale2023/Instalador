﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration.Attributes;

namespace ConsoleAppNet4
{
    public class Assay
    {
        [Name("Sample Id")]
        public string SampleId { get; set; }
        [Name("Lot Number")]
        public string LotNumber { get; set; }
        [Name("Client Id Reception")]
        public string CLient_id_reception { get; set; }
        [Name("Commodity")] 
        public string Commodity { get; set; }
        [Name("Quality")]
        public string Quality { get; set; }
        [Name("Net Weight")]
        public decimal NetWeight { get; set; }
        [Name("Leave Date")]
        public DateTime LeaveDate { get; set; }

    }
}
