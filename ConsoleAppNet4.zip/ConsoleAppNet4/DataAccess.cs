﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;


namespace  ConsoleAppNet4

{
    public class DataAccess
    {
        public List<Assay> GetAssay(String IniPer , string FinPer, string sSource)
        {
            
            
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal(sSource)))
            {
                return connection.Query<Assay>(@"SELECT [SampleId], [Lot Number], [client_id_reception], [Commodity], [Quality], [NetWeight], [LeaveDate] FROM [QV_SAMPLES_QLIK] Where LeaveDate between '" + IniPer + "' and '" + FinPer +"'" ).ToList();
                    
            }
        }
    }

}
