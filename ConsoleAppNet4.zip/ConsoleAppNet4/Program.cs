﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CsvHelper;
using Dapper;


namespace ConsoleAppNet4
{
    internal class Program
    {

        static void Main(string[] args)
        {
            //Company code sent as parameter
            // CCW, IMX
            string sEmpresa="";
            string sSever = Environment.MachineName;
            int _sleep;
               
            MessageBox.Show(sSever, "Step2");
            try
            { 
                _sleep = int.Parse(System.Configuration.ConfigurationManager.AppSettings[sSever.ToLower()]); 
            }
            catch (ArgumentNullException e)
                {
                _sleep = 0;
            }
            MessageBox.Show(_sleep.ToString(), "sleep");
            if (args.Length > 0)
            {
                sEmpresa = args[0];
                if ((sEmpresa.Contains("CCW")) || (sEmpresa.Contains("IMX")))
                {
                    List<Assay> Result = new List<Assay>();

                    String OutputFile = "";
                    String PathFile = "";
                    String DataSourcePE = "";
                    String DataSourceMX = "";
                    String DataSourceCL = "";
                    

                    DateTime IniDay, FinDay;
                    String SIniDay, SFinDay, sDateFile;

                    FinDay = DateTime.Now;
                    SFinDay = FinDay.ToString("yyy-MM-dd");
                    sDateFile = FinDay.ToString("ddMMyyyy");

                    MessageBox.Show(SFinDay, "Step1");

                    IniDay = FinDay.AddDays(-7);
                    SIniDay = IniDay.ToString("yyy-MM-dd");



                    MessageBox.Show(SIniDay, "Step2");

                    PathFile = System.Configuration.ConfigurationManager.AppSettings["PathDropFile"];
                    DataSourcePE = System.Configuration.ConfigurationManager.AppSettings["DataSourcePE"];
                    DataSourceMX = System.Configuration.ConfigurationManager.AppSettings["DataSourceMX"];
                    DataSourceCL = System.Configuration.ConfigurationManager.AppSettings["DataSourceCL"];


                    OutputFile = PathFile + sEmpresa+ "OnlimsSampling" + sDateFile + ".csv";

                    MessageBox.Show(OutputFile, "OutpuitFile");

                    
                    DataAccess db = new DataAccess();
                    Result = db.GetAssay(SIniDay, SFinDay, (sEmpresa == "IMX") ? DataSourceMX : ((sEmpresa == "CCW") ? DataSourcePE: DataSourceCL));
                    if (Result.Count == 0)
                    {
                        MessageBox.Show("Vacio", "Step4");
                    }
                    else
                    {
                        MessageBox.Show($"Lleno " + Result.Count.ToString(), "step5");
                    }
                    ///pause
                    ///
                    Thread.Sleep(_sleep);
                    ///
                    if (!File.Exists(OutputFile))
                    {

                        using (var writer = new StreamWriter(OutputFile))
                        {
                            using (var csvOut = new CsvWriter(writer, CultureInfo.InvariantCulture))
                            {
                                csvOut.WriteRecords(Result);
                            }
                        }
                        MessageBox.Show("Grabado", "Step6");
                    } else
                    {
                        MessageBox.Show("No Grabado archivo existe", "Step7");
                    }
                    

                }
                else
                {
                    MessageBox.Show("Error", "Empresa no Valida");
                    throw new Exception("Invalid Parameter");
                }
            }
            else
            {
                MessageBox.Show("Error", "Invalid Parametros");
                throw new Exception("Invalid Parameter");
            }
        }
    }
}
